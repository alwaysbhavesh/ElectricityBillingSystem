package electricity.billing.system;

import java.sql.*;

public class Conn {
    // 5 steps to connect jdbc in java
    // Register the Driver class
    // Create connection
    // Create statement
    // Execute queries
    // Close connection
    Connection c;
    Statement s;

    Conn() {
        // Class.forName("com.mysql.cj.jdbc.Drivers");//Register
        try {// creating connection
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/ebs", "root", "password");
            s = c.createStatement();// create statement
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

// import java.sql.Connection;
// import java.sql.DriverManager;
//
// public class Conn{
// public static void main(String[] args) {
// try{
// Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ebs",
// "root", "password");
// }catch (Exception e){
// }
// }
// }