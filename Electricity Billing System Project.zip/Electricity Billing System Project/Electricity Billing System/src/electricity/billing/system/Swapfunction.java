package electricity.billing.system;
import java.util.Scanner;

public class Swapfunction {
    public static void main(String[] args) {
        int a,b;
        System.out.println("Enter two numbers");
        Scanner sc=new Scanner(System.in);
        a=sc.nextInt();
        b=sc.nextInt();
        System.out.println("Before Swapping:"+a+"and"+b);
        a=a+b;
        b=a-b;
        a=a-b;
        System.out.println("Before Swapping:"+a+"and"+b);
    }
}
