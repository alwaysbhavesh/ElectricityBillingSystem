package electricity.billing.system;
import javax.swing.*;
import java.awt.*;

public class SplashScreen extends JFrame implements Runnable
    //gives error: runnable interface has a method run which is abstract in nature
    //to remove this error after getting from implements Runnable well ovveride method run
{
    Thread t;
    SplashScreen() {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/elect.jpg"));

        Image i2=i1.getImage().getScaledInstance(730,550,Image.SCALE_DEFAULT);

        ImageIcon i3=new ImageIcon(i2);//Image ki scale pue gui ki frae ki tarah ho

        JLabel image=new JLabel(i3);
        add(image);

        setVisible(true);//setting visibility
        int x=1;
        for(int i=2;i<600;i+=4,x+=1) {
            setSize(i+x, i);
            //setLocation(600, 250);//open screen in center otherwise it will open in top left
            setLocation(940-((i+x)/2), 500-(i/2));//open screen in center otherwise it will open in top left

            //apni screen aur smoothly khulne keliye ye try catch use kiya hai
            try{
                Thread.sleep(5);
            }catch (Exception e){
                e.printStackTrace();
            }
        }


        t=new Thread(this);
        t.start();//start method will internally call ruun method we cannot call runn method directly in multithreading in java

    }

    public void run(){//this will help us to close the screen after 7seconds
        try{
            Thread.sleep(3000);
            setVisible(false);

            //login frame here:
            new Login();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        new SplashScreen();
    }
}